# LoxBerry-Plugin-SamplePlugin-V2-PHP
This is the LoxBerry 0.3.x Sample Plugin for PHP
