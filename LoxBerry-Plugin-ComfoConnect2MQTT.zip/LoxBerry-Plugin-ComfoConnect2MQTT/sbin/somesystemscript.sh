#!/bin/bash

# Can be executed with sudo as user "loxberry".
echo "A script which can be executed with sudo as user loxberry."
